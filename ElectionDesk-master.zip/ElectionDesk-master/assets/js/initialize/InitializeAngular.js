angular.module('electiondesk', [
	'ngSanitize',
	'btford.socket-io',
	'timeRelative',
	'ui.bootstrap',
	'ui.bootstrap-slider',
	'cgNotify',
	'linkify'
]);