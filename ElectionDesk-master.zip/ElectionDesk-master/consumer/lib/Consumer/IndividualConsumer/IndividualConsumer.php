<?php namespace Consumer\IndividualConsumer;

use Consumer\Consumer;

class IndividualConsumer extends Consumer {
	public function consume($filter) {
		
	}
}