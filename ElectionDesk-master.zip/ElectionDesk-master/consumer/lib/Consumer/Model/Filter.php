<?php namespace Consumer\Model;

use Illuminate\Database\Eloquent\Model;

class Filter extends Model {
	
	public $table = 'filters';
	public $timestamps = false;
	
}