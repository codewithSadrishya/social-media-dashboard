<?php namespace Consumer\Model;

use Illuminate\Database\Eloquent\Model;

class UserAccount extends Model {
	public $table = 'user_accounts';
	public $timestamps = false;
	
}