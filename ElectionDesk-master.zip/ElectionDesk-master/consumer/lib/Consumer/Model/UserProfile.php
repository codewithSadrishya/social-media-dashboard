<?php namespace Consumer\Model;

use Illuminate\Database\Eloquent\Model;

class UserProfile extends Model {
	public $table = 'user_profiles';
	public $timestamps = false;
	
}