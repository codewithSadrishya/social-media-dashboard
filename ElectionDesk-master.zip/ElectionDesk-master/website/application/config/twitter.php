<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
/**
 * twitter
 * 
 * Config for Twitter
 *
 * @author Simon Emms <simon@simonemms.com>
 */

/* Access tokens */
$config['twitter'] = array(
    'consumer_key' => TWITTER_CONSUMER_KEY,
    'consumer_secret' => TWITTER_CONSUMER_SECRET,
    //'access_key' => TWITTER_ACCESSTOKEN,
    //'access_secret' => TWITTER_ACCESSTOKEN_SECRET
);

?>