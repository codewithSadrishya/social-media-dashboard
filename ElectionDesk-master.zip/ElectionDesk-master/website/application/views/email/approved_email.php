<p>Congratulations! Your ElectionDesk account has been verified.</p>

<p>You may now use this email address to <a href="<?php echo site_url('auth/login'); ?>">log-in to ElectionDesk</a> and begin engaging with voters in your area.</p>

<p>We hope you find ElectionDesk helpful when engaging with voters and disseminating information to your local community on Election Day 2012.</p>

<p>If you have any questions or require further assistance, please <a href="<?php echo site_url('help'); ?>">submit a request to the Help Desk</a>.</p>

