	<h1>Priority <span style="font-size: 50px; font-weight: bold; color: orange;"><?php echo $priority; ?></span></h1>
	<h2>New Ticket for Election Desk</h2>
	
	
	<h3><strong>Name:</strong> <?php echo $first_name.' '.$last_name; ?></h3>
	<h3><strong>Email:</strong> <?php echo $email; ?></h3>
	
	
	<h4>Message:</h4>
	<p><?php echo $message; ?></p>