<p>Dear <?php echo $first_name.' '.$last_name; ?>,</p>

<p>Our support team has received your submission and will review your ticket shortly.  Please note that tickets are reviewed by priority and in the order they were submitted.</p>

<p>In the meantime, follow us <a href="http://twitter.com/electiondesk">@ElectionDesk</a> on twitter for updates.</p>

