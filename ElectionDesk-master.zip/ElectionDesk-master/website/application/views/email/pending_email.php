<p>Thanks for signing up for ElectionDesk!</p>

<p>Your account is currently pending and requires authorization from the ElectionDesk staff.</p>

<p>Please respond to this email with the name, address and phone number of the election jurisdiction with which you are affiliated. You will receive an email confirmation when your account is approved.</p>

<p>If you have any questions or require further assistance, please <a href="<?php echo site_url('/help'); ?>">submit a request to the Help Desk</a>.</p>