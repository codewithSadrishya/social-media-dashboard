<h1>Your new password on <?php echo $site_name; ?></h1>

<h3>You have changed your password.</h3>
<h3>Please, keep it in your records so you don't forget it.</h3>

<h2>Your email address: <?php echo $email; ?></h2>
