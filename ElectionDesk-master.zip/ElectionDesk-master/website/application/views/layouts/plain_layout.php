<!DOCTYPE html>
<html lang="en">
<head>
	<?php echo $head; ?>
</head>
<body class="plain">
	<?php echo $content; ?>
</body>
</html>