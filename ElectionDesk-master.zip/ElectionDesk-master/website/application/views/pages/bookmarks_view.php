<h1>
	Bookmarks
	<a href="/" class="btn btn-warning pull-right"><i class="fa fa-angle-double-left"></i> Go back</a>
</h1>

<div ng-controller="BookmarksController">
<?php
echo $stream;
?>
</div>
