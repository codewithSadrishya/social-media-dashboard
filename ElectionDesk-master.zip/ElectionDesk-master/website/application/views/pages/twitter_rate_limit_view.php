<div id="container">
	
	<div class="subhead">
		<h3>Error</h3>
		<p>Could not fetch data</p>
	</div><!-- end subhead -->
	
	<div class="content">
		<h3>Twitter rate limit exceeded. Please try again in a few minutes.</h3>
	</div><!-- end content -->

</div>